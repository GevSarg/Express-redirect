export const users = [
  {
    id: 1,
    email: "anna@gmail.com",
    password: "user1234",
  },
  {
    id: 2,
    email: "john.admin@gmail.com",
    password: "admin1234",
  },
  {
    id: 3,
    email: "james.superadmin@gmail.com",
    password: "superadmin",
  },
  {
    id: 4,
    email: "marcus.admin@gmail.com",
    password: "admin1234",
  },
  {
    id: 5,
    email: "carl@gmail.com",
    password: "user1234",
  },
];
