export const routes = [
  { path: "/", file: "index.html" },
  { path: "/user", file: "user.html" },
  { path: "/login", file: "login.html" },
  { path: "/admin", file: "admin.html" },
  { path: "/superadmin", file: "super-admin.html" },
];
